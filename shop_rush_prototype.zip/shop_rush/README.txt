SHOP RUSH — playable prototype v1

HOW TO PLAY
- Open index.html in a modern browser (Chrome recommended).
- Tap START SHOPPING.
- Swipe left/right on mobile, or use Left/Right arrow keys on desktop.
- Collect grocery emojis to score and earn virtual coins.
- Avoid brown crates. One collision ends the shift.
- Coins and best score save locally in this browser.

PLATFORM
This is a responsive HTML5 Canvas prototype for modern Android and desktop browsers.
It is not yet an installed Android APK. For an Android app, a later step can package
the web game with Capacitor and test it on a real device.

MONETIZATION
No ads or real-money purchases are included in this prototype. Add ads only after
gameplay is tested, with consent/privacy disclosures and compliant ad placements.
Optional purchases should be cosmetic or convenience-based, clearly priced, and
never required to play. Virtual coins in this demo have no cash value.

NEXT
1. Play and test on phone + desktop.
2. Improve art, add sound, missions, store upgrades and more obstacle types.
3. Add settings/accessibility and test performance.
4. Add analytics and privacy policy.
5. Integrate a supported ad SDK and optional in-app purchases before release.
